

|    | platform    | company   | job                                                                                                                                                            | update_time   | location        |
|---:|:------------|:----------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------|:----------------|
|  1 | SimplyHired | Capgemini | [Delivery Architect - Sr Design Verification Engineer](https://www.simplyhired.com/job/TG0t9VuP7luIxURJzs0qd0hcdD3ADyErgLS19TILSBCQdgadGyVO7g?q=arvr+designer) | Recently      | Santa Clara, CA |