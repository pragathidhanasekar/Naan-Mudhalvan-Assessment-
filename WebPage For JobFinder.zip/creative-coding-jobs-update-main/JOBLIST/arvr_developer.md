

|    | platform    | company          | job                                                                                                                                                                      | update_time   | location      |
|---:|:------------|:-----------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------|:--------------|
|  1 | SimplyHired | Cleveland Clinic | [Associate Director Technology and Development- Digital Health](https://www.simplyhired.com/job/U20vkDabVWYuEmzOUU9n6blXJNmjJeE1dWnaNzXvloUJnySYx3hgkA?q=arvr+developer) | Recently      | Cleveland, OH |