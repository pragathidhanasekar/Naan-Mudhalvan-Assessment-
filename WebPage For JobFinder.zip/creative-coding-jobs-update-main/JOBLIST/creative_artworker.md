

|    | platform    | company     | job                                                                                                                                        | update_time   | location   |
|---:|:------------|:------------|:-------------------------------------------------------------------------------------------------------------------------------------------|:--------------|:-----------|
|  1 | SimplyHired | OPEN Health | [Associate Creative Director](https://www.simplyhired.com/job/Cp5zNzLDuJ10YCW0ynW_jh9Kl1UpNp5Gio--ZGfLv8CSJz3Lde5FLQ?q=creative+artworker) | Recently      | Remote     |