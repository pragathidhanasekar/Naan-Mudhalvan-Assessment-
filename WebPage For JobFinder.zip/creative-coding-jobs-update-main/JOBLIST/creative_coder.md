

|    | platform    | company        | job                                                                                                                                | update_time   | location    |
|---:|:------------|:---------------|:-----------------------------------------------------------------------------------------------------------------------------------|:--------------|:------------|
|  1 | SimplyHired | Premier Health | [SURGICAL CODER - PPC](https://www.simplyhired.com/job/qrksAQ0BW0abHjA-BtE5UhwE2LlEG9lG8j7klH6ZUPFe5yuRBFPZrw?q=creative+coder)    | 7d            | Moraine, OH |
|  2 | SimplyHired | Red Lobster    | [Email Coding Specialist](https://www.simplyhired.com/job/FIx7-ptt9Mz1VEe_iQHrAqWlq1plGcqIRNXQT593C5i_qtC1Phse4Q?q=creative+coder) | Recently      | Orlando, FL |