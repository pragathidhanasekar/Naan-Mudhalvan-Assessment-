class BaseSetting:
    platform_name = None
    platform_url = None
    query = None
    referer_list = None