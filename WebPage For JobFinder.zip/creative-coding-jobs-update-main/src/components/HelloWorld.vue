<template>
  <div class="hello"></div>
</template>

<script>
export default {
  name: 'HelloWorld'
}
</script>

<style scoped>

</style>
