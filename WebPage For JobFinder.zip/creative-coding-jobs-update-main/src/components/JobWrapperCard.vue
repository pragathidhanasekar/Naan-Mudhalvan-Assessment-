<template>
  <div>
    {{ job }}
  </div>
</template>

<script>
export default {
  name: 'JobWrapperCard',
  props: ['job']
}
</script>
